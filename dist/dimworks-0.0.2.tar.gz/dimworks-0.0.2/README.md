#  **dimworks** 


## Project Description


This package is to calcuate quality statistics, like Cpk, Ppk by Python



## Current Status

This project is under continuing  development.




